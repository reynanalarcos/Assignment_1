/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package exercise3312023;
import java.util.Scanner;
/**
 *
 * @author lucifer
 */
public class TotalStockReturn {
    public static void main(String[] args) {
        // Create a Scanner object to read input from the keyboard
        Scanner scanner = new Scanner(System.in);
        System.out.println("Welcome to Total Stock Return!");
        System.out.println("Name: Reynan Alarcos ");
        System.out.println("Student ID#: TI1011247");
        // Prompt the user for the initial stock price
        System.out.print("Enter the initial stock price: ");
        double initialStockPrice = scanner.nextDouble();

        // Prompt the user for the ending stock price
        System.out.print("Enter the ending stock price: ");
        double endingStockPrice = scanner.nextDouble();

        // Prompt the user for the dividends
        System.out.print("Enter the dividends: ");
        double dividends = scanner.nextDouble();

        // Calculate the total stock return
        double totalStockReturn = ((endingStockPrice + dividends) / initialStockPrice) - 1;

        // Display the total stock return as a percentage
        System.out.println("Total Stock Return: " + (totalStockReturn * 100) + "%");

        // Close the Scanner
        scanner.close();
    }
}
