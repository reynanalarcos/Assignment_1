/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package exercise3312023;
import java.util.Scanner;
/**
 *
 * @author lucifer
 */
public class OopConcept {
    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);

        // Step 1: Access code validation
        System.out.println("Welcome to ATM!");
        System.out.println("Name: Reynan Alarcos");
        System.out.println("Student ID#: TI1011247");
        System.out.println("Enter access code:");
        String accessCode = input.nextLine();
        boolean isValidAccessCode = validateAccessCode(accessCode);

        // Step 2: Withdrawal amount input
        if (isValidAccessCode) {
            System.out.println("Access code valid.");
            System.out.println("Enter withdrawal amount:");
            double withdrawalAmount = input.nextDouble();

            // Step 3: Cash withdrawal
            boolean isCashDispensed = dispenseCash(withdrawalAmount);

            if (isCashDispensed) {
                // Step 4: Receipt printing
                System.out.println("Cash dispensed successfully.");
                System.out.println("Print receipt? (yes/no):");
                String printReceipt = input.next();
                if (printReceipt.equalsIgnoreCase("yes")) {
                    printReceipt();
                }
            } else {
                System.out.println("Insufficient balance.");
            }
        } else {
            System.out.println("Invalid access code.");
        }
    }

    // Method to validate access code (dummy implementation)
    public static boolean validateAccessCode(String accessCode) {
        // Replace this with your actual access code validation logic
        // For example, you can check against a database or a list of valid access codes
        // This is just a dummy implementation for illustration purposes
        return accessCode.equals("1234");
    }

    // Method to dispense cash (dummy implementation)
    public static boolean dispenseCash(double withdrawalAmount) {
        // Replace this with your actual cash withdrawal logic
        // For example, you can check against available balance, ATM limits, etc.
        // This is just a dummy implementation for illustration purposes
        double availableBalance = 1000.0; // Assuming available balance is $1000
        if (withdrawalAmount <= availableBalance) {
            return true;
        } else {
            return false;
        }
    }

    // Method to print receipt
    public static void printReceipt() {
        // Replace this with your actual receipt printing logic
        // This is just a dummy implementation for illustration purposes
        System.out.println("Receipt printed successfully.");
        System.out.println("Thank you for using our ATM.");
    }
}
