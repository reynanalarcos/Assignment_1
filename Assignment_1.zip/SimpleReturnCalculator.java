/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package exercise3312023;
import java.util.Scanner;
/**
 *
 * @author lucifer
 */
public class SimpleReturnCalculator {
    public static void main(String[] args) {
        // Create a Scanner object to read input from the keyboard
        Scanner scanner = new Scanner(System.in);
        System.out.println("Welcome to Simple Return Calculator!");
        System.out.println("Name: Reynan Alarcos ");
        System.out.println("Student ID#: TI1011247");
        // Prompt the user for net proceeds, dividends, and cost basis
        System.out.print("Enter net proceeds: ");
        double netProceeds = scanner.nextDouble();
        System.out.print("Enter dividends: ");
        double dividends = scanner.nextDouble();
        System.out.print("Enter cost basis: ");
        double costBasis = scanner.nextDouble();

        // Calculate the simple return
        double totalReturn = netProceeds + dividends;
        double simpleReturn = (totalReturn - costBasis) / costBasis * 100;

        // Display the results
        System.out.println("Net Proceeds: $" + netProceeds);
        System.out.println("Dividends: $" + dividends);
        System.out.println("Cost Basis: $" + costBasis);
        System.out.println("Simple Return: " + simpleReturn + "%");

        // Close the Scanner
        scanner.close();
    }
}
