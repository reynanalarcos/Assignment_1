/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package exercise3312023;
import java.util.Scanner;
/**
 *
 * @author lucifer
 */
public class StudentMarksCalculator {
    public static void main(String[] args) {
        // Create a Scanner object to read input from the keyboard
        Scanner scanner = new Scanner(System.in);
        System.out.println("Welcome to Student Marks Calculator!");
        System.out.println("Name: Reynan Alarcos ");
        System.out.println("Student ID#: TI1011247");
        // Prompt the user for student name
        System.out.print("Enter student name (at least 6 characters): ");
        String studentName = scanner.nextLine();

        // Check if student name has at least 6 characters
        if (studentName.length() < 6) {
            System.out.println("Error: Student name must have at least 6 characters.");
            return;
        }

        // Prompt the user for marks in 5 subjects
        System.out.println("Enter marks for 5 subjects:");
        System.out.print("English 101: ");
        int subject1Marks = scanner.nextInt();
        System.out.print("Mathematics 102: ");
        int subject2Marks = scanner.nextInt();
        System.out.print("History 5: ");
        int subject3Marks = scanner.nextInt();
        System.out.print("Chemistry 402: ");
        int subject4Marks = scanner.nextInt();
        System.out.print("Physics 106: ");
        int subject5Marks = scanner.nextInt();

        // Calculate total and average of marks
        int totalMarks = subject1Marks + subject2Marks + subject3Marks + subject4Marks + subject5Marks;
        double averageMarks = (double) totalMarks / 5;

        // Display the results
        System.out.println("Student Name: " + studentName);
        System.out.println("Total Marks: " + totalMarks);
        System.out.println("Average Marks: " + averageMarks);

        // Close the Scanner
        scanner.close();
    }
}
