/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package exercise3312023;
import java.util.Scanner;
/**
 *
 * @author lucifer
 */
public class BMICalculator {
    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
        System.out.println("Welcome to BMI Calculator!");
        System.out.println("Name: Reynan Alarcos ");
        System.out.println("Student ID#: TI1011247");
        System.out.println("Enter weight in kilograms: ");
        double weight = input.nextDouble();

        System.out.println("Enter height in meters: ");
        double height = input.nextDouble();

        // Calculate BMI
        double bmi = weight / (height * height);

        // Display BMI and corresponding message
        System.out.println("BMI: " + bmi);
        if (bmi < 18) {
            System.out.println("Underweight");
        } else if (bmi >= 19 && bmi < 24) {
            System.out.println("Healthy");
        } else if (bmi >= 25) {
            System.out.println("Obese");
        }
    }
}
