/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package exercise3312023;
import java.util.Scanner;
/**
 *
 * @author lucifer
 */
public class CurrencyConverter {
    public static void main(String[] args) {
        // Create a Scanner object to read input from the keyboard
        Scanner scanner = new Scanner(System.in);
        System.out.println("Welcome to Currecy Converter!");
        System.out.println("Name: Reynan Alarcos ");
        System.out.println("Student ID#: TI1011247");
        // Prompt the user for the currency conversion
        System.out.println("Select an option:");
        System.out.println("1. INR to CAD");
        System.out.println("2. GBP to USD");
        System.out.print("Enter your choice: ");
        int choice = scanner.nextInt();

        // Perform the currency conversion based on user's choice
        double rate;
        double amount;
        switch (choice) {
            case 1:
                rate = 0.018; // Exchange rate from INR to CAD
                System.out.print("Enter amount in INR: ");
                amount = scanner.nextDouble();
                double convertedAmountINRtoCAD = amount * rate;
                System.out.println("Converted amount: " + convertedAmountINRtoCAD + " CAD");
                break;
            case 2:
                rate = 1.37; // Exchange rate from GBP to USD
                System.out.print("Enter amount in GBP: ");
                amount = scanner.nextDouble();
                double convertedAmountGBPtoUSD = amount * rate;
                System.out.println("Converted amount: " + convertedAmountGBPtoUSD + " USD");
                break;
            default:
                System.out.println("Invalid choice. Please select a valid option.");
                break;
        }

        // Close the Scanner
        scanner.close();
    }
}
